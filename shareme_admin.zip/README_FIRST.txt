SQUARAGE ADMIN DASHBOARD - SETUP PACKAGE
=========================================

This zip contains everything you need to run the Squarage Admin Dashboard on a new computer.

CONTENTS:
---------
1. .env.local - Environment variables (KEEP THIS FILE SECURE!)
2. SETUP_INSTRUCTIONS.md - Detailed setup instructions
3. README_FIRST.txt - This file

QUICK START:
------------
1. Clone the repo: git clone https://github.com/tubbyflumpkins/admin_squarage.git
2. Copy the .env.local file from this zip to the project root
3. Run: npm install
4. Run: npm run dev
5. Open: http://localhost:3000

IMPORTANT SECURITY NOTE:
------------------------
The .env.local file contains sensitive information including:
- Database connection string
- Authentication secrets
- API keys

DO NOT share this file publicly or commit it to version control!

For detailed instructions, see SETUP_INSTRUCTIONS.md

If you're using Claude or another AI assistant to help with setup:
Just share the SETUP_INSTRUCTIONS.md file with them, and they'll guide you through the process.

SUPPORT:
--------
If you have issues, the project includes:
- CLAUDE.md for AI assistance
- AUTHENTICATION.md for auth system details
- Extensive code comments

Good luck!